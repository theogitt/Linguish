using UnityEngine;
using TMPro;
using System;

public class DialogueUI_TESTING : MonoBehaviour
{

    [SerializeField] private GameObject containerDialogueUI;
    [SerializeField] private PlayerInterection_TESTING playerInteraction; //There is a keybind option here, for advancing through dialogue

    [SerializeField] private TextMeshProUGUI dialogueText;
    [SerializeField] private TextMeshProUGUI interactableName; //Named it this cause not sure if we want other things beside NPC to have Dialogue, like a door can have a quick short dialogue being like "Sealed from the inside"

    void Start()
    {
        Hide();
    }

    private void Show()
    {
        containerDialogueUI.SetActive(true);
    }

    private void Hide()
    {
        containerDialogueUI.SetActive(false);
    }

    public void ShowDialogue (string name, string dialogue)
    {
        if (string.IsNullOrWhiteSpace(dialogue))
        {
            return;
        }

        if (containerDialogueUI.activeSelf == true)
        {
            return;
        }

        interactableName.text = name;

        dialogueText.text = dialogue;

        Show();
    }

    public void CloseDialogue()
    {
        Hide();
    }

    void Update()
    {
        
    }
}
